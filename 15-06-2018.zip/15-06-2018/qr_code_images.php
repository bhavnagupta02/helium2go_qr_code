<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<?php
include 'db.php';
$folder = $_GET['folder'];
?>
<h2 style="text-align: center;"><?php echo $folder;?></h2>

<div class="modified_images">
  <?php $sql = "SELECT * FROM qr_codes WHERE folder = '$folder'";
        $query = mysqli_query($conn, $sql);
		$i = 1;
		while($fetch = mysqli_fetch_assoc($query)){
   ?>
	   <img class="qr-image" id="qr_code_image_<?php echo $i;?>" src=<?php echo $fetch['qr_code_img'];?> /> 
	<?php $i++; } ?>			
</div>
